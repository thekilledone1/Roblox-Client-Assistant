@echo off
setlocal
set "APP_DIR=%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

"%PS%" -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -LiteralPath '%APP_DIR%RobloxClientAssistant.bat','%APP_DIR%RobloxClientAssistant.ps1' -ErrorAction SilentlyContinue"
start "" "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%APP_DIR%RobloxClientAssistant.ps1" -Hidden
